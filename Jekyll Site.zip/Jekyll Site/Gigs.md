---
title: News/Gigs
layout: blog
permalink: gigs
---

# Regular updates will be posted on our facebook page.
## [Facebook](https://www.facebook.com/LURocSoc/).
