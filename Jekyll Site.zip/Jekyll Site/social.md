---
title: Social Media
layout: page
permalink: social
---

<p><a href="https://www.facebook.com/pg/LURocSoc" target="_blank">Facebook</a></p>

<p>Discord(Message us on FB)</p>

<p><a href="https://www.instagram.com/lurocsoc/" target="_blank">Instagram</a></p>

<p><a href="https://twitter.com/RocSoc" target="_blank">Twitter</a></p>

<p><a href="mailto:rocsoc@lancaster.ac.uk" target="_blank">Email</a></p>

<p> Links will open in a new tab.</p>
