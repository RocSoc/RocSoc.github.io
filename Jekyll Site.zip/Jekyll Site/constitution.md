---
title: Constitution
image: "/assets/logos/logoog.png"
layout: page
permalink: Constitution
---

# [2020/2021](/assets/RocSoc_Constitution_2020-2021.docx)


