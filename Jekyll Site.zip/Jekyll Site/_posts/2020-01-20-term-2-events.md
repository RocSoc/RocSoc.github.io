---
title: Term 2 Events
image: "/assets/logos/logoog.png"
layout: post
categories: news
description: |-
  Look in awe, RocSoc!
  Your calendar for this term!
---

Look in awe, RocSoc!
Your calendar for this term!
Get this stapled to your forehead so you never miss an event!

In addition to these confirmed events, another GIG on a Friday at the end of term is to be confirmed, so keep your eyes on this page!

![](/assets/Posters/CAL_T2_19-20.png)

Also the upcoming AGM is on the 5th February at 7pm Furness LT3.

[Current Constitution](/Constitution)