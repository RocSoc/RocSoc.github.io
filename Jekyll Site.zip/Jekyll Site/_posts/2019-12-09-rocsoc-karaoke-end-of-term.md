---
title: RocSoc Karaoke/End of Term
layout: post
categories: news
description: |-
  It is time to celebrate your journey so far with a much beloved RocSoc tradition!
  Instead of listening to professional singers and getting drunk, you'll be doing the singing! (And getting drunk.)
---

When you entered RocSoc for the first time this year you were but mere children.

Now? You are Gods. 

It is time to celebrate your journey so far with a much beloved RocSoc tradition!
Instead of listening to professional singers and getting drunk, you'll be doing the singing! (And getting drunk.)

Yes, the fabled RocSoc Karaoke Social is here! Warm up those vocal chords, because you'll be showing off your talents for your fellow members!

There's no better way to end a term than to get up in front of a microphone and make a fool of yourself for three minutes for the enjoyment of your peers, and this is your best opportunity to do it!

See you there, RocSoc!