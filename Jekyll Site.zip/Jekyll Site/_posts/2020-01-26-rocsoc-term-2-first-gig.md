---
image: "/assets/logos/logoog.png"
title: RocSoc - Term 2 FIRST GIG!
layout: post
categories: Gigs
description: "'A gig already?' At our Monday Social on this, the third week of the
  second term, we will be proud to hand over the Yorkie's stage to acts that will
  leave your skull shaken, your blood pumping and the bevs flowing!"
---

'A gig already?' 

Yes, Friends! For the RocSoc exec never sleeps!
At our Monday Social on this, the third week of the second term, we will be proud to hand over the Yorkie's stage to acts that will leave your skull shaken, your blood pumping and the bevs flowing!

Your ears will be assaulted by the unforgiving tones of our first act, WOLFBASTARD! With tracks such as 'Drink Fucking Beer, Hail Fucking Satan' and 'Sick in the Bath', this is a black metal outfit all our members will relate to!

The astounding guitar and vocal skills of Joe Sinnot and his range of acoustic covers will provide the perfect backing track as the weakest of you are wheeled away on a stretcher. Those of us who are still breathing will be treated to some fantastic renditions of the classics, this is not an act you want to miss!

RocSoc members get the fantastic discounted price of just £2 for entry to the gig, as opposed to our usual £5 entry price!

 Fantastic poster work done by the ever talented Alaina Harrison!

Facebook: Alaina Rhiannon Harrison
Instagram: alaina.r.harrison
Twitter: @AlainaRhiannon

![](/assets/Posters/2020GIG1.PNG)
