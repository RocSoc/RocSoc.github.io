---
title: 'RocSoc Presents: Insurgency, Andracca, Flying Volts!'
layout: post
categories: Gigs
description: |-
  Three legends approach, o'er the horizon.
  destined to open pits (we hope no-one dies in.)

  Insurgency! Andracca! Flying Volts!
  WILL SHRED WHILST BEVS FLOW DOWN YOUR THROATS!
image: "/assets/Photos/philandy.jpg"
---

## Monday, 29 October 2019 from 20:00-23:30

### The Yorkshire House, Lancaster 

Listen up, runts, for there is a tale to tell...
the most horrific time of year deserves riffs straight from hell...

For on tuesday night, when the moon is dark,
in the name of the sesh, on a voyage we'll embark.

Three legends approach, o'er the horizon.
destined to open pits (we hope no-one dies in.)

Insurgency! Andracca! Flying Volts!
WILL SHRED WHILST BEVS FLOW DOWN YOUR THROATS!

They'll come to us on our home ground.
They'll FLOOD the Yorkie with their sound!

SO DON'T MISS OUT, AND DO REMEMBER:
Entry's cheaper if you're a member.

That's right RocSoc, our first gig of the year. We've secured local legends: Flying Volts, Andracca, and Insurgency!
This Tuesday at 20:30 at the Yorkie, you'll get the chance to see all three bands play a set for just £5 on the door (£3 for RocSoc member's card holders!)
The lineup even includes some of RocSoc's alumni!

See you there!

![](/assets/Posters/2019GIG1.jpg)
![](/assets/Photos/philandy.jpg)