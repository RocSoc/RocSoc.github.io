---
title: New Exec & End Of Exec Party!
image: "/assets/logos/logoog.png"
layout: post
categories: news
description: It's time to do what Rocsoc does best, get together in a pub older than
  all of us and get drunk, this time to send off the old exec and welcome the new
  through the bottom of a pint glass.
---

It's your new resident shitposter here (not like the old one has gone far) and it's time to do what Rocsoc does best, get together in a pub older than all of us and get drunk, this time to send off the old exec and welcome the new through the bottom of a pint glass.

For you disgraceful lot who didnt show at the elections here is your new exec team:
* President - Kiera Bernardo
* Vice Pres - Joshua Murphy
* Treasurer - August J-h
* Social Sec - Philip Bond
* Publicity - James Sargeant
* Health & Safety - Sara Jayne Toole
* Secretary - Luke Williams
* As well as your DJs:
* Tom Kaye and Ben Myles

With a very tough contest for each role last week, scalps pulled and hands bitten, the final victors are ready for whatever Rocsoc needs and all that jazz.
According to all known laws of..
No, gotta stay on topic.
Come Yorkie on Monday night at 8pm to drink and listen to the dankest of music, most likely ending up in Gen before we know it.
Disclaimer: Rocsoc does not endorse drinking..
..or does it?



Congrats you read this far, have a good pat on the back