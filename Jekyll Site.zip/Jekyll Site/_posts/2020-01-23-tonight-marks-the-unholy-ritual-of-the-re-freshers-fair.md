---
title: Tonight... marks the Unholy ritual of the re-freshers fair.
image: "/assets/logos/logoog.png"
layout: post
categories: news
description: We are at the Unholy ritual of the re-freshers fair.
---

For those of you unfortunate enough to have missed out on our prodigous first term, we offer a second chance...

Tonight only, for a special discounted price of £3 for a membership, you can join the society dedicated to rock, metal, and Tuesday morning headaches!

Every Monday, RocSoc's members flock to the Yorkie pub in town. There we host concerts, request socials, themed socials and more!

Once a term we travel to a faraway land to spread our extravagant ways to the local populace, joining today will be your best bet to march with us to Manchester!

We are dedicated to having a good time, so if you are looking for a weekly hangout with some heavy metal sprinkled in, we're your society!

See you there!