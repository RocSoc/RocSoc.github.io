---
title: Events
image: "/assets/logos/logoog.png"
permalink: Events
layout: page
---

## 2019: Term 2:


![](/assets/Posters/CAL_T2_19-20.png)


Also the upcoming AGM is on the 5th February at 7pm Furness LT3.

[Current Constitution](/Constitution)