---
title: Join Us
permalink: join
layout: page
---

# [https://lancastersu.co.uk/groups/rocsoc](https://lancastersu.co.uk/groups/rocsoc)
Link that will redirect you to Lancaster University Students’ Union's societies.

<p>Discord(Message us on FB)</p>

Unfortunatley due to 'The Virus™' NO ROCSOC FACE TO FACE events can take place in the michaelmas term (so says LUSU.)
However RocSoc will be continuing its current weekly scheduled  Discord calls (featuring a 'pub' quiz, a robot DJ and the ability to chat with fellow members without fear of being coughed on.) These calls are currently every Monday at 8:30pm-Late.

